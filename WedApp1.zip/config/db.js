module.exports = {
      url : 'mongodb://blakeandolivia:bermuda1@ds131511.mlab.com:31511/wedapp'
    //  url :  'mongodb://root:bermuda1@35.188.98.102:27017/admin'
}
